﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Dikdortgen
    {
        private double kisaKenar;
        private double uzunKenar;
        public Dikdortgen()
        {
            kisaKenar = 1;
            uzunKenar = 1;
        }
        public Dikdortgen(int kisa, int uzun)
        {
            kisaKenar = kisa;
            uzunKenar = uzun;
        }
        public double AlanHesapla()
        {
            return kisaKenar * uzunKenar;
        }

        public double CevreHesapla()
        {
            return 2 * (kisaKenar + uzunKenar);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Dikdortgen d = new Dikdortgen(5,7);
            Console.WriteLine("Alan: {0}", d.AlanHesapla());
            Console.WriteLine("Cevre: {0}", d.CevreHesapla());
            Console.ReadLine();
        }
    }
}
