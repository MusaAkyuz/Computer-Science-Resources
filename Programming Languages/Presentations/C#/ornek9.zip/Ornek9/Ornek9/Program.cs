﻿using System;
using System.Data.OleDb;

namespace Ornek9
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Data.OleDb.OleDbConnection conn = new System.Data.OleDb.OleDbConnection();
            try
            {
                
                conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;" + @"Data source= Database1.accdb";
                conn.Open();
                string sql = "SELECT * FROM Table1";
                OleDbDataReader reader = null;
                OleDbCommand command = new OleDbCommand(sql, conn);
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine(reader[3].ToString() + " " + reader[1].ToString() + " " + reader[2].ToString());
                }

                /*sql = "INSERT INTO Table1 (OgrenciNo,Isim,Soyisim,Bolum) VALUES (5,'Yeni','Ogr','Makine')";
                command = new OleDbCommand(sql, conn);
                command.ExecuteNonQuery();*/

                conn.Close();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                conn.Close();
            }
        }
    }
}
