#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
int main(int argc,char **argv){
        pid_t Ana_pid, c_pid1, c_pid2;
        Ana_pid=getpid();
        printf("PID:%d\n",Ana_pid);
        c_pid1=fork();
		c_pid2=fork();
        if(c_pid1==0){
			c_pid2=fork();
            printf("Bu cocuk proses:%d\n",getpid());
        }else {
                printf("Bu ana proses:%d\n",getpid());
        }
        sleep(10);
        return 0;
}

