/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javadocexmp1;

/**
 *
 * @author Önder
 */
public class JavaDocExmp1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Point B=new Point(3,4);
    }
    
}
