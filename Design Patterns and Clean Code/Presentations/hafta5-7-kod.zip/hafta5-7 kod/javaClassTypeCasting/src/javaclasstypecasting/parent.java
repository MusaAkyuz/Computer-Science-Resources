/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaclasstypecasting;

/**
 *
 * @author Onder Eyecioglu
 */
public class parent {
    public int p;
    parent(int x){
        p=x;
    } 
    void show()
  {
    System.out.println("Parent show method is called:"+this.p);
  }
}
