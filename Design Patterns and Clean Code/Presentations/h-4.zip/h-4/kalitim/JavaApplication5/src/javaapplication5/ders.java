/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication5;

/**
 *
 * @author Pc Lab 03 Hoca
 */
public class ders {
    public String Adi;
    public int Kodu;
    public int Kredi;
   
    ders(String a, int k, int kr){
       Adi=a;
       Kodu=k;
       Kredi=kr;
    }
    
}
